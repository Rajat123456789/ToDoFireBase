package com.example.firebasetodo;

public class MyDoes {
    String m_list_item_title;
    String m_list_item_content;

    public MyDoes() {
    }

    public MyDoes(String m_list_item_title, String m_list_item_content) {
        this.m_list_item_title = m_list_item_title;
        this.m_list_item_content = m_list_item_content;
    }

    public String getM_list_item_title() {
        return m_list_item_title;
    }

    public void setM_list_item_title(String m_list_item_title) {
        this.m_list_item_title = m_list_item_title;
    }

    public String getM_list_item_content() {
        return m_list_item_content;
    }

    public void setM_list_item_content(String m_list_item_content) {
        this.m_list_item_content = m_list_item_content;
    }
}
