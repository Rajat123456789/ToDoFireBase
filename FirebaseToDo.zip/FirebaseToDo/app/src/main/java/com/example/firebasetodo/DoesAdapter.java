package com.example.firebasetodo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DoesAdapter extends RecyclerView.Adapter<DoesAdapter.MyViewHolder> {

    Context context;
    ArrayList<MyDoes> myDoes;

    public DoesAdapter(Context c, ArrayList<MyDoes> p) {
        context = c;
        myDoes =p;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.to_do_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.m_list_item_title.setText(myDoes.get(position).getM_list_item_title());
        holder.m_list_item_content.setText(myDoes.get(position).getM_list_item_content());

    }

    @Override
    public int getItemCount() {
        return myDoes.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        AppCompatTextView m_list_item_content;
        AppCompatTextView m_list_item_title;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            m_list_item_content = (AppCompatTextView) itemView.findViewById(R.id.list_item_content);
            m_list_item_title = (AppCompatTextView) itemView.findViewById(R.id.list_item_title);
        }
    }
}
